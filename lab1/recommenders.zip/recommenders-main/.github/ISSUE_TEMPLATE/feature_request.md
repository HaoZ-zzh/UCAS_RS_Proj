---
name: Feature request
about: Suggest an idea for this project
title: "[FEATURE] "
labels: 'enhancement'
assignees: ''

---

### Description
<!--- Describe your expected feature in detail -->

### Expected behavior with the suggested feature
<!--- For example:  -->
<!--- *Adding algorithm xxx will help people understand more about xxx use case scenarios. -->

### Other Comments
