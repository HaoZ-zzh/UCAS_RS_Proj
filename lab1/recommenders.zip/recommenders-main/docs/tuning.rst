.. _tuning:

Hyperparameter tuning module
*********************************
Hyperparameter tuning module from Recommenders utilities.


Parameter sweep utils
===============================
.. automodule:: recommenders.tuning.parameter_sweep
    :members: